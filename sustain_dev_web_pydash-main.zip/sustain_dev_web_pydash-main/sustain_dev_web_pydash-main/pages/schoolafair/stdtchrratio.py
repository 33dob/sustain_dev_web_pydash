import dash
from dash import dcc, html, callback
from dash.dependencies import Input, Output
import plotly.graph_objects as go
import pandas as pd


data = pd.read_parquet('./datas/student_teacher_ratio.parquet')

dash.register_page(__name__)

lang = ["中文", 'English']

layout = html.Div([
    dcc.Link(html.Button("Home",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/", refresh=True),
    
    dcc.RadioItems(id='lang_stdtch_checklist', 
                    options=lang,
                    value="中文",
                    labelStyle={"margin":"0.2rem"},
                    inline=True,
                    style={
                        # 'marginLeft':"86%",
                        }
                ),

    #html.H2("各學年度日間學制師生比與師生人數"),
    dcc.Graph(id='std-dual-axis-bar-line-chart'),    
    html.Div(id='stdtchrratio-team'),
    # html.P("Teamwork by Sandy, Emily, Debbie, and Ilham , directed by Prof. Ching-Shih Tsou. All rights reserved",
    #            style={
    #                'marginTop' : "10px",
    #                'textAlign' : "center",
    #                }),
])
@callback(
    Output('stdtchrratio-team', 'children'),
    Input('lang_stdtch_checklist', 'value')
)
def update_labels(lang):
    if lang == "English":
        return (
            html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }),
        )
    else:
        return (
            html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }),
        )
@callback(
    Output('std-dual-axis-bar-line-chart', 'figure'),
    [Input('std-dual-axis-bar-line-chart', 'id'),Input('lang_stdtch_checklist', 'value')]
)
def update_chart(_,select):
    if select == "English":
        fig = go.Figure()

        fig.add_trace(go.Bar(
            x=data['學年度'],
            y=data['日間學制學生數'],
            name='Number of students',
            text=data['日間學制學生數'],
            hovertemplate='<b>%{x}</b><br>Number of students: %{y}<extra></extra>',
        ))

        fig.add_trace(go.Bar(
            x=data['學年度'],
            y=data['日間專任教師(含助教)'],
            name='Number of teachers',
            text=data['日間專任教師(含助教)'],
            hovertemplate='<b>%{x}</b><br>Number of teachers: %{y}<extra></extra>',
        ))

        fig.add_trace(go.Scatter(
            x=data['學年度'],
            y=data['日間生師比'],
            mode='lines+markers',
            name='Daytime teacher-student ratio',
            yaxis='y2',
        ))

        # 設定圖表佈局
        fig.update_layout(
            title='Teacher-student ratio and number of teachers and students in day school system in each school year',
            xaxis=dict(title='School year'),
            yaxis=dict(title='Number of people'),
            yaxis2=dict(title='Daytime teacher-student ratio', overlaying='y', side='right'),
            barmode='group',
            legend=dict(x=1.1, y=1),
        )
    else:    
        fig = go.Figure()

        fig.add_trace(go.Bar(
            x=data['學年度'],
            y=data['日間學制學生數'],
            name='學生數',
            text=data['日間學制學生數'],
            hovertemplate='<b>%{x}</b><br>學生數: %{y}<extra></extra>',
        ))

        fig.add_trace(go.Bar(
            x=data['學年度'],
            y=data['日間專任教師(含助教)'],
            name='老師數',
            text=data['日間專任教師(含助教)'],
            hovertemplate='<b>%{x}</b><br>老師數: %{y}<extra></extra>',
        ))

        fig.add_trace(go.Scatter(
            x=data['學年度'],
            y=data['日間生師比'],
            mode='lines+markers',
            name='日間生師比',
            yaxis='y2',
        ))

        # 設定圖表佈局
        fig.update_layout(
            title='各學年度日間學制師生比與師生人數',
            xaxis=dict(title='學年度'),
            yaxis=dict(title='人數'),
            yaxis2=dict(title='日間生師比', overlaying='y', side='right'),
            barmode='group',
            legend=dict(x=1.1, y=1),
        )

    return fig
