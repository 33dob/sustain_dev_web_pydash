import dash
import pandas as pd
import plotly.express as px
from dash import callback, dcc, html, no_update,Dash
from dash.dependencies import Input, Output

dash.register_page(__name__)

df = pd.read_parquet('./datas/brosischool.parquet')

# 計算每個國家的學校數量
country_counts = df.groupby(['區域別', '國家']).size().reset_index(name='學校數量')

lang = ["中文", 'English']

# 設定佈局 (Set layout)
layout = html.Div([
    dcc.Link(html.Button("Home",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/", refresh=True),
    dcc.RadioItems(id='lang_school_checklist', 
                       options=lang,
                       value="中文",
                       labelStyle={"margin":"0.2rem"},
                       inline=True,
                       style={
                           # 'marginLeft':"86%",
                            }
                    ),

    dcc.Graph(id = 'brosischool', 
              style={
                  'marginLeft': "10px",
                             }),

    html.Div(id='brosischool-team')

    # html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
    #            style={
    #                'marginTop' : "10px",
    #                'textAlign' : "center",
    #                }),
    ])

# 設置回調函數 (Set callback function)
@callback(
    Output('brosischool', 'figure'),
    Output('brosischool-team', 'children'),
    [Input('lang_school_checklist', 'value')]
)
def update_brosischool(select):
    if select == "English":
        df = pd.read_parquet('./datas/brosischool_en.parquet')

        # 計算每個國家的學校數量
        country_counts = df.groupby(['Region', 'Country']).size().reset_index(name='Number of Schools')
        fig = px.choropleth(country_counts,
                    locations="Country",  # 國家: Country
                    locationmode='country names',
                    color="Number of Schools",  # 學校數量: Number of Schools
                    hover_name="Country",  # 國家: Country
                    hover_data=['Region', 'Number of Schools'],  # 區域別: Region, 學校數量: Number of Schools
                    color_continuous_scale=px.colors.sequential.Plasma,
                    labels={'Number of Schools':'Number of Schools'},
                    projection="natural earth",
                    title="International University Sister School Distribution Map"
                    )
        team = html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
    else:
        df = pd.read_parquet('./datas/brosischool.parquet')

        # 計算每個國家的學校數量
        country_counts = df.groupby(['區域別', '國家']).size().reset_index(name='學校數量')
        # 生成 choropleth 地圖
        fig = px.choropleth(country_counts,
                            locations="國家",
                            locationmode='country names',
                            color="學校數量",
                            hover_name="國家",
                            hover_data=['區域別', '學校數量'],
                            color_continuous_scale=px.colors.sequential.Plasma,
                            labels={'學校數量':'學校數量'},
                            projection="natural earth",
                            title="大學國際姊妹校分布圖"
                            )
        team = html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
    return fig, team