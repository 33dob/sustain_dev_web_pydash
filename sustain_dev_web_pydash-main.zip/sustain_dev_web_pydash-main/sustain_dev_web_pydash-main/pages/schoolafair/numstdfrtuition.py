import dash
import pandas as pd
# import plotly.express as px
from dash import callback, dcc, html
from dash.dependencies import Input, Output
import plotly.graph_objects as go

dash.register_page(__name__)

lang = ["中文", 'English']

layout = html.Div([
    dcc.Link(html.Button("Home",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/", refresh=True),

    dcc.RadioItems(id='lang_frtuition_checklist', 
                    options=lang,
                    value="中文",
                    labelStyle={"margin":"0.2rem"},
                    inline=True,
                    style={
                        # 'marginLeft':"86%",
                        }
                ),

    html.Div(id='frtuition-title-div'),
    #html.H2("不同學年度的學雜費減免人數"),
    
    dcc.Graph(id='stdfrtuition',style={'textAlign':'center'}),
    html.Div(id='numstdfr-team'),
    # html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
    #            style={
    #                'marginTop' : "10px",
    #                'textAlign' : "center",
    #                }),
])

# 設置回調函數 (Set callback function)
@callback(
    Output('frtuition-title-div', 'children'),
    Output('numstdfr-team', 'children'),
    Input('lang_frtuition_checklist', 'value')
)
def update_labels(lang):
    if lang == "English":
        return (html.H2("Number of people exempted from tuition and miscellaneous fees by another academic year"),
            html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }),)
    else:
        return (html.H2("不同學年度的學雜費減免人數"),
            html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }))

# 設置回調函數 (Set callback function)
@callback(
    Output('stdfrtuition', 'figure'),
    Input('lang_frtuition_checklist', 'value')
)

def update_parallel_categories(select):
    if select == "English":
        file_path = './datas/stdfees_en.parquet'
        df = pd.read_parquet(file_path)

        # Process the data
        years = df['academic year'].unique()
        data = {year: {} for year in years}

        for index, row in df.iterrows():
            year = row['academic year']
            for column in df.columns[6:]:
                category = column.replace('Number of people exempted from tuition and miscellaneous fees -', '')
                category = category.replace('學雜費減免人數-小計', 'Totel')
                if category not in data[year]:
                    data[year][category] = 0
                data[year][category] += row[column]

        for year in years:
            data[year] = dict(sorted(data[year].items(), key=lambda x: x[1]))

        # Create the Plotly bar chart
        fig = go.Figure()

        bar_width = 0.15
        index = list(range(len(years)))

        for i, category in enumerate(data[years[0]].keys()):
            fig.add_trace(go.Bar(
                x=[x + i * bar_width for x in index],
                y=[data[year][category] for year in years],
                name=category,
                text=[data[year][category] for year in years],
                textposition='auto'
            ))

        # Update the layout
        fig.update_layout(
            # title='不同學年度的學雜費減免人數',
            xaxis=dict(
                title='Academic year',
                tickvals=[r + bar_width * ((len(data[years[0]]) - 1) / 2) for r in range(len(years))],
                ticktext=years
            ),
            yaxis=dict(
                title='Number of people exempted from tuition and miscellaneous fees'
            ),
            barmode='group',
            legend=dict(
                title='Type',
                x=1.05,
                y=1,
                xanchor='left',
                yanchor='top'
            ),
            margin=dict(t=40, b=40, l=40, r=40),
            width=1000,
            height=600
        )
        
    else:
        file_path = './datas/stdfees.parquet'
        df = pd.read_parquet(file_path)

        # Process the data
        years = df['學年度'].unique()
        data = {year: {} for year in years}

        for index, row in df.iterrows():
            year = row['學年度']
            for column in df.columns[6:]:
                category = column.replace('學雜費減免人數-', '')
                if category not in data[year]:
                    data[year][category] = 0
                data[year][category] += row[column]

        for year in years:
            data[year] = dict(sorted(data[year].items(), key=lambda x: x[1]))

        # Create the Plotly bar chart
        fig = go.Figure()

        bar_width = 0.15
        index = list(range(len(years)))

        for i, category in enumerate(data[years[0]].keys()):
            fig.add_trace(go.Bar(
                x=[x + i * bar_width for x in index],
                y=[data[year][category] for year in years],
                name=category,
                text=[data[year][category] for year in years],
                textposition='auto'
            ))

        # Update the layout
        fig.update_layout(
            # title='不同學年度的學雜費減免人數',
            xaxis=dict(
                title='學年度',
                tickvals=[r + bar_width * ((len(data[years[0]]) - 1) / 2) for r in range(len(years))],
                ticktext=years
            ),
            yaxis=dict(
                title='減免人數'
            ),
            barmode='group',
            legend=dict(
                title='類別',
                x=1.05,
                y=1,
                xanchor='left',
                yanchor='top'
            ),
            margin=dict(t=40, b=40, l=40, r=40),
            width=800,
            height=600
        )

    return fig






    
 