import pandas as pd
import dash
from dash import callback, html, dcc, Input, Output, State
# from dash.dependencies import Input, Output, State
import plotly.express as px

dash.register_page(__name__)

lang = ["中文", 'English']

layout = html.Div([
    dcc.Link(html.Button("Home",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/", refresh=True),
    
    dcc.RadioItems(id='lang_dropout_checklist', 
                       options=lang,
                       value="中文",
                       labelStyle={"margin":"0.2rem"},
                       inline=True,
                       style={
                           # 'marginLeft':"86%",
                            }
                    ),

    #lang
    html.Div(id='dropout-dropdown'),

    dcc.Checklist(
        id='dropstdn-checklist',
        inline=True
    ),

    dcc.Graph(id='dropout-bar-chart'),

    html.Div(id='dropout-team'),

])

@callback(
    Output('dropout-dropdown', 'children'),
    Output('dropout-team', 'children'),
    Input('lang_dropout_checklist', 'value')
)
def update_labels(lang):
    if lang == "English":
        return (
            dcc.Dropdown(id='dropout-status-dropdown',options=[
                    {'label': 'Withdrawals', 'value': 'Withdrawals'},
                    {'label': 'Suspensions', 'value': 'Suspensions'}],
                        value='Withdrawals'),
            html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }),
        )
    else:
        return (
            dcc.Dropdown(id='dropout-status-dropdown',options=[
                    {'label': '退學', 'value': 'Withdrawals'},
                    {'label': '休學', 'value': 'Suspensions'}],
                        value='Withdrawals'),
            html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }),
        )

@callback(
    Output('dropstdn-checklist', 'value'),
    Output('dropstdn-checklist', 'options'),
    Input('lang_dropout_checklist', 'value')
    
)

def update_checklist_options(lang):
    if lang == 'English':
        # Load the data
        file_out_path = './datas/top10out_en.parquet'
        file_rest_path = './datas/top10rest_en.parquet'

        df_out = pd.read_parquet(file_out_path)
        df_rest = pd.read_parquet(file_rest_path)

        # Filter data for the years 108 to 112
        filtered_out_df = df_out[df_out['退學學年'].between(108, 112)]
        filtered_rest_df = df_rest[df_rest['休學學年'].between(108, 112)]

        edu_short_options = [{'label': edu_short, 'value': edu_short} for edu_short in filtered_out_df['Edu_short_english'].unique()] 
        #+ [{'label': 'Clear / All', 'value': 'clear'}]
        edu_short_value = [edu_short for edu_short in filtered_out_df['Edu_short_english'].unique()]
    else:
        # Load the data
        file_out_path = './datas/top10out.parquet'
        file_rest_path = './datas/top10rest.parquet'

        df_out = pd.read_parquet(file_out_path)
        df_rest = pd.read_parquet(file_rest_path)

        # Filter data for the years 108 to 112
        filtered_out_df = df_out[df_out['退學學年'].between(108, 112)]

        edu_short_options = [{'label': edu_short, 'value': edu_short} for edu_short in filtered_out_df['Edu_Short'].unique()] 
        #+ [{'label': '清空/全選', 'value': 'clear'}]
        edu_short_value = [edu_short for edu_short in filtered_out_df['Edu_Short'].unique()]
    return edu_short_value, edu_short_options
'''
@callback(
    Output('dropstdn-checklist', 'value'),
    [Input('dropstdn-checklist', 'value')],
    State('dropstdn-checklist', 'options')
)
def update_checklist(selected_values, options):
    all_options = [option['value'] for option in options if option['value'] != 'clear']
    if 'clear' in selected_values:
        if len(selected_values) == 1:
            return all_options
        return ['clear']
    return selected_values
'''
@callback(
    Output('dropout-bar-chart', 'figure'),
    [Input('dropout-status-dropdown', 'value'), Input('dropstdn-checklist', 'value'),Input('lang_dropout_checklist', 'value')]
)

def update_bar_chart(selected_status, selected_edu_short, lang):
    if lang == 'English':
        # Load the data
        file_out_path = './datas/top10out_en.parquet'
        file_rest_path = './datas/top10rest_en.parquet'

        df_out = pd.read_parquet(file_out_path)
        df_rest = pd.read_parquet(file_rest_path)

        # Filter data for the years 108 to 112
        filtered_out_df = df_out[df_out['退學學年'].between(108, 112)]
        filtered_rest_df = df_rest[df_rest['休學學年'].between(108, 112)]

        if 'clear' in selected_edu_short:
            selected_edu_short = []
        
        if selected_status == 'Withdrawals':
            filtered_df = filtered_out_df[filtered_out_df['Edu_short_english'].isin(selected_edu_short)]
            top_10_schools = filtered_df['Sch_Name_en'].value_counts().head(10).reset_index(name='Count').rename(columns={'index': 'Sch_Name_en'})
            title = 'Top 10 Schools by Number of Withdrawals (Years 108-112)'
        else:
            filtered_df = filtered_rest_df[filtered_rest_df['Edu_short_english'].isin(selected_edu_short)]
            top_10_schools = filtered_df['Sch_Name_en'].value_counts().head(10).reset_index(name='Count').rename(columns={'index': 'Sch_Name_en'})
            title = 'Top 10 Schools by Number of Suspensions (Years 108-112)'

        fig = px.bar(top_10_schools, x='Count', y='Sch_Name_en', orientation='h', 
                    title=title, labels={'Sch_Name_en': 'School Name', 'Count': 'Count'})
    else:
        # Load the data
        file_out_path = './datas/top10out.parquet'
        file_rest_path = './datas/top10rest.parquet'

        df_out = pd.read_parquet(file_out_path)
        df_rest = pd.read_parquet(file_rest_path)

        # Filter data for the years 108 to 112
        filtered_out_df = df_out[df_out['退學學年'].between(108, 112)]
        filtered_rest_df = df_rest[df_rest['休學學年'].between(108, 112)]

        if 'clear' in selected_edu_short:
            selected_edu_short = []
        
        if selected_status == 'Withdrawals':
            filtered_df = filtered_out_df[filtered_out_df['Edu_Short'].isin(selected_edu_short)]
            top_10_schools = filtered_df['Sch_Name'].value_counts().head(10).reset_index(name='Count').rename(columns={'index': 'Sch_Name'})
            title = '前十名生源學校的退學人數 (學年度 108-112)'
        else:
            filtered_df = filtered_rest_df[filtered_rest_df['Edu_Short'].isin(selected_edu_short)]
            top_10_schools = filtered_df['Sch_Name'].value_counts().head(10).reset_index(name='Count').rename(columns={'index': 'Sch_Name'})
            title = '前十名生源學校的休學人數 (學年度 108-112)'

        fig = px.bar(top_10_schools, x='Count', y='Sch_Name', orientation='h', 
                    title=title, labels={'Sch_Name': '學校名稱', 'Count': '人數'})
    
    return fig


