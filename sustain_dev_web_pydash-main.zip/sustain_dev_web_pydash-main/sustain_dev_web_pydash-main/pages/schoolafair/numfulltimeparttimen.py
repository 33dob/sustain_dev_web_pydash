import dash
from dash import dcc, html, callback
from dash.dependencies import Input, Output, State
import plotly.graph_objects as go
import pandas as pd

# 讀取專任和兼任教師資料
file_path_full_time = './datas/fulltime.parquet'
file_path_part_time = './datas/parttime.parquet'
data_full_time = pd.read_parquet(file_path_full_time)
data_part_time = pd.read_parquet(file_path_part_time)

# 定義分類
categories = {
    "Administration": ["Physical Education Office", "Center for General Education", "Military Education Office"],
    "Departments": ["Department of Finance", "Department of International Business", "Department of Accounting Information", "Department of Business Administration", "Department of Public Finance and Tax Administration", "Department of Accounting and Data Science", "Department of Information Management", "Department of Creative Technologies and Product Design", "Department of Applied Foreign Languages", "Department of Digital Multimedia Design", "Department of Creative Technologies and Product Design", "Department of Creative Technologies and Product", "Department of Commercial Design and Management"],
    "Graduate Institutes": ["Institute of Creative Design and Management", "Master's Program on Law and Negotiation for Global Trade", "Institute of Information and Decision Sciences"],
    "Colleges": ["School of Accounting and Finance", "Ph.D. Program in School of Accounting and Finance"]
}

# 初始化 Dash 應用
dash.register_page(__name__)

# 定義選項
teacher_types = ['Full-time', 'Part-time'] # Full-time, Part-time

layout = html.Div([
     dcc.Link(html.Button("Home",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/", refresh=True),
    dcc.Link(html.Button("中文",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/schoolafair/numfulltimeparttim", refresh=True),

    dcc.Link(html.Button("英文",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/schoolafair/numfulltimeparttimen", refresh=True),

                
    html.H1("Number of Full-time/Part-time Teachers in Daytime Programs by Academic Year"), # Number of Full-time/Part-time Teachers in Daytime Programs by Academic Year
    html.Div([
        html.Label("Category Selection:"), # Category Selection
        dcc.Checklist(
            id='category-selector-en',
            options=[{'label': cat, 'value': cat} for cat in categories.keys()],
            value=[],
            labelStyle={'display': 'inline-block'}
        )
    ]),
    html.Div(id='department-div-en', children=[
        html.Label("Select Department Category:"), # Select Department Category
        dcc.Checklist(
            id='department-selectoren',
            options=[],
            value=[],
            labelStyle={'display': 'inline-block'}
        )
    ]),
    html.Div(id='teacher-type-en-div', children=[
        html.Label("Select Teacher Type:"), # Select Teacher Type
        dcc.Checklist(
            id='teacher-type-en-selector',
            options=[{'label': 'all', 'value': 'all'}] + [{'label': t, 'value': t} for t in teacher_types],
            value=[],
            labelStyle={'display': 'inline-block'}
        )
    ]),
    dcc.Graph(id='line-chart-en'),
            html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
])

def update_checklist(selected_options, all_options):
    if 'all' in selected_options:
        if set(selected_options) == set(['all'] + list(all_options)):
            return []
        else:
            return ['all'] + list(all_options)
    return selected_options

@callback(
    Output('department-selectoren', 'options'),
    [Input('category-selector-en', 'value')]
)
def update_department_options(selected_categories):
    if not selected_categories:
        return []
    departments = []
    for category in selected_categories:
        departments.extend(categories[category])
    return [{'label': 'all', 'value': 'all'}] + [{'label': dept, 'value': dept} for dept in departments]

@callback(
    Output('department-selectoren', 'value'),
    [Input('department-selectoren', 'value')],
    [State('department-selectoren', 'options')]
)
def update_department_selector(selected_options, options):
    if not options:
        return []
    all_options = [option['value'] for option in options if option['value'] != 'all']
    return update_checklist(selected_options, all_options)

@callback(
    Output('teacher-type-en-div', 'style'),
    [Input('department-selectoren', 'value')]
)
def update_teacher_type_visibility(selected_departments):
    if selected_departments:
        return {'display': 'block'}
    return {'display': 'none'}

@callback(
    Output('teacher-type-en-selector', 'value'),
    [Input('teacher-type-en-selector', 'value')],
    [State('teacher-type-en-selector', 'options')]
)
def update_teacher_type_selector(selected_options, options):
    if not options:
        return []
    all_options = [option['value'] for option in options if option['value'] != 'all']
    return update_checklist(selected_options, all_options)

@callback(
    Output('line-chart-en', 'figure'),
    [
        Input('teacher-type-en-selector', 'value'),
        Input('department-selectoren', 'value')
    ]
)
def update_chart(selected_teacher_types, selected_departments):
    fig = go.Figure()

    # 移除 'all' 選項
    selected_teacher_types = [t for t in selected_teacher_types if t != 'all']
    selected_departments = [d for d in selected_departments if d != 'all']

    # 如果未選擇任何教師類型或系所，不顯示資料
    if not selected_teacher_types or not selected_departments:
        fig.update_layout(
            title='Number of Full-time/Part-time Teachers in Daytime Programs by Academic Year', # Number of Full-time/Part-time Teachers in Daytime Programs by Academic Year
            xaxis=dict(title='Academic Year'), # Academic Year
            yaxis=dict(title='Total Number') # Total Number
        )
        return fig

    for teacher_type in selected_teacher_types:
        data = data_full_time if teacher_type == 'Full-time' else data_part_time
        for dept in selected_departments:
            filtered_data = data[data['Academic and Administrative Units'] == dept] # Unit Name
            total_column = '專任教師數-教師總數總計' if teacher_type == 'Full-time' else '兼任教師數-教師總數總計' # Number of Teachers - Total Teacher Count
            if total_column in filtered_data.columns:
                fig.add_trace(go.Scatter(
                    x=filtered_data['學年度'], # Academic Year
                    y=filtered_data[total_column],
                    mode='lines+markers',
                    name=f'{teacher_type} {dept} Total Number' # Total Number
                ))

    # 設定圖表佈局
    fig.update_layout(
        title='Number of Full-time/Part-time Teachers in Daytime Programs by Academic Year', # Number of Full-time/Part-time Teachers in Daytime Programs by Academic Year
        xaxis=dict(title='Academic Year'), # Academic Year
        yaxis=dict(title='Total Number'), # Total Number
        legend=dict(x=1.1, y=1),
    )

    return fig