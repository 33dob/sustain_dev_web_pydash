import pandas as pd
import dash
from dash import dcc
from dash import html, callback
from dash.dependencies import Input, Output
import plotly.express as px

dash.register_page(__name__)

lang = ["中文", 'English']

layout = html.Div([
    dcc.Link(html.Button("Home",
                    style={
                        'backgroundColor':"#800080",
                        'color':"white",
                    #  'marginBottom':"20px",
                        'borderRadius':"8px",
                        'borderWidth': "thin",
                        'borderStyle':"solid",
                        'borderColor':"#C6C4C4",
                        }), href="/", refresh=True),
            
    dcc.RadioItems(id='lang_yearrestout_checklist', 
                options=lang,
                value="中文",
                labelStyle={"margin":"0.2rem"},
                inline=True,
                style={
                    # 'marginLeft':"86%",
                    }
            ),
    
    html.Div(id='yearrestout-tab'),

    dcc.RadioItems(
        id='year-edu-short-radioitems',
        inline=True
    ),
   
    html.Div(id='year-graphs-container'),

    html.Div(id='yearrestout-team'),
])

@callback(
    Output('yearrestout-tab', 'children'),
    Output('yearrestout-team', 'children'),
    Input('lang_yearrestout_checklist', 'value')
)
def update_labels(lang):
    if lang == "English":
        return (
            dcc.Tabs(id='status-tabs', value='Suspensions', children=[
                dcc.Tab(label='Suspensions', value='Suspensions'),
                dcc.Tab(label='Withdrawals', value='Withdrawals'),
            ]),
            html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }),
        )
    else:
        return (
            dcc.Tabs(id='status-tabs', value='Suspensions', children=[
                dcc.Tab(label='休學', value='Suspensions'),
                dcc.Tab(label='退學', value='Withdrawals'),
            ]),
            html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }),
        )

@callback(
    Output('year-edu-short-radioitems', 'options'),
    Output('year-edu-short-radioitems', 'value'),
    Input('lang_yearrestout_checklist', 'value')
)
def update_edu_short_options(lang):
    if lang == "English":
        # Load the data
        df_out = pd.read_parquet('./datas/yearoutnum_en.parquet')
        # Filter data for the years 108 to 112
        filtered_out_df = df_out[df_out['退學學年'].between(106, 112)]
        
        edu_short_options = [{'label': edu_short, 'value': edu_short} for edu_short in filtered_out_df['Edu_short_english'].unique()]
        edu_short_value = filtered_out_df['Edu_short_english'].unique()[0] if edu_short_options else None
    
    else:
        # Load the data
        df_out = pd.read_parquet('./datas/yearoutnum.parquet')
        # Filter data for the years 108 to 112
        filtered_out_df = df_out[df_out['退學學年'].between(106, 112)]
        
        edu_short_options = [{'label': edu_short, 'value': edu_short} for edu_short in filtered_out_df['Edu_Short'].unique()]
        edu_short_value = filtered_out_df['Edu_Short'].unique()[0] if edu_short_options else None

    return edu_short_options, edu_short_value


@callback(
    Output('year-graphs-container', 'children'),
    Input('status-tabs', 'value'), Input('year-edu-short-radioitems', 'value'),Input('lang_yearrestout_checklist', 'value')
)
def update_graphs(selected_status, selected_edu_short, lang):
    if lang == "English":
        # Load the data
        df_out = pd.read_parquet('./datas/yearoutnum_en.parquet')
        df_rest = pd.read_parquet('./datas/yearrestnum_en.parquet')
        # Filter data for the years 108 to 112
        filtered_out_df = df_out[df_out['退學學年'].between(108, 112)]
        filtered_rest_df = df_rest[df_rest['休學學年'].between(108, 112)]

        if selected_status == 'Withdrawals':
            filtered_df = filtered_out_df[filtered_out_df['Edu_short_english'] == selected_edu_short]
            year_column = '退學學年'
            title = 'Comparison chart of the number of Withdrawals'
        else:
            filtered_df = filtered_rest_df[filtered_rest_df['Edu_short_english'] == selected_edu_short]
            year_column = '休學學年'
            title = 'Comparison chart of the number of Suspensions'

        department_list = filtered_df['Department(Abbreviated)'].unique()
        graphs = []

        colors = px.colors.qualitative.Plotly

        for idx, department in enumerate(department_list):
            department_df = filtered_df[filtered_df['Department(Abbreviated)'] == department]
            grouped_df = department_df.groupby(year_column).size().reset_index(name='Count')

            fig = px.bar(grouped_df, x=year_column, y='Count', 
                        title=f'{department} {title} (Academic year 106-112)', labels={year_column: 'Academic year', 'Count': 'Number of people'}, 
                        barmode='stack',
                        color_discrete_sequence=[colors[idx % len(colors)]])

            fig.update_layout(xaxis=dict(tickmode='linear'))

            total_counts = grouped_df.groupby(year_column)['Count'].sum().reset_index()
            for index, row in total_counts.iterrows():
                fig.add_annotation(
                    x=row[year_column],
                    y=row['Count'],
                    text=f"{row['Count']} people in total",
                    showarrow=False,
                    yshift=10
                )

            graphs.append(dcc.Graph(figure=fig))
    else:
        # Load the data
        df_out = pd.read_parquet('./datas/yearoutnum.parquet')
        df_rest = pd.read_parquet('./datas/yearrestnum.parquet')
        # Filter data for the years 108 to 112
        filtered_out_df = df_out[df_out['退學學年'].between(108, 112)]
        filtered_rest_df = df_rest[df_rest['休學學年'].between(108, 112)]

        if selected_status == 'Withdrawals':
            filtered_df = filtered_out_df[filtered_out_df['Edu_Short'] == selected_edu_short]
            year_column = '退學學年'
            title = '退學人數比較圖'
        else:
            filtered_df = filtered_rest_df[filtered_rest_df['Edu_Short'] == selected_edu_short]
            year_column = '休學學年'
            title = '休學人數比較圖'

        department_list = filtered_df['系所'].unique()
        graphs = []

        colors = px.colors.qualitative.Plotly

        for idx, department in enumerate(department_list):
            department_df = filtered_df[filtered_df['系所'] == department]
            grouped_df = department_df.groupby(year_column).size().reset_index(name='Count')

            fig = px.bar(grouped_df, x=year_column, y='Count', 
                        title=f'{department} {title} (學年度 106-112)', labels={year_column: '學年度', 'Count': '人數'}, 
                        barmode='stack',
                        color_discrete_sequence=[colors[idx % len(colors)]])

            fig.update_layout(xaxis=dict(tickmode='linear'))

            total_counts = grouped_df.groupby(year_column)['Count'].sum().reset_index()
            for index, row in total_counts.iterrows():
                fig.add_annotation(
                    x=row[year_column],
                    y=row['Count'],
                    text=f"共 {row['Count']} 人",
                    showarrow=False,
                    yshift=10
                )

            graphs.append(dcc.Graph(figure=fig))

    return graphs
