import pandas as pd
import dash
from dash import dcc, html, Input, Output, callback
import plotly.express as px
from dash.exceptions import PreventUpdate

dash.register_page(__name__)

lang = ["中文", 'English']

'''df_out = pd.read_parquet('./datas/numoutadmiss.parquet')
df_rest = pd.read_parquet('./datas/numrestadmiss.parquet')

df_outen = pd.read_parquet('./datas/numoutadmiss_en.parquet')
df_resten = pd.read_parquet('./datas/numrestadmiss_en.parquet')

# Filter data for the years 108 to 112 and exclude "夜二專"
filtered_out_df = df_out[df_out['退學學年'].between(108, 112) & (df_out['Edu_Short'] != '夜二專')]
filtered_rest_df = df_rest[df_rest['休學學年'].between(108, 112) & (df_rest['Edu_Short'] != '夜二專')]'''

layout = html.Div([
    dcc.Link(html.Button("Home",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/", refresh=True),

    dcc.RadioItems(id='lang_drp_checklist', 
                    options=lang,
                    value="中文",
                    labelStyle={"margin":"0.2rem"},
                    inline=True,
                    style={
                        # 'marginLeft':"86%",
                        }
                ),
    #獨自
    dcc.Dropdown(
        id='status-drp-dropdown',
        options=[
            {'label': '退學', 'value': 'Withdrawals'},
            {'label': '休學', 'value': 'Suspensions'}
        ],
        value='Withdrawals'
    ),

    #關聯
    html.Div(id='edu-short-drp'),

    #關聯
    html.Div(id='bar-chart-drp', style={
            'overflowY':"scroll",
            'height':"850px",
        }),
    
    html.Div(id='dropoutsix-team'),
    
    # html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
    
    #            style={
    #                'marginTop' : "10px",
    #                'textAlign' : "center",
    #                }),
])

@callback(
    Output('status-drp-dropdown', 'options'),
    Output('dropoutsix-team', 'children'),
    Input('lang_drp_checklist', 'value')
)
def update_options(lang):
    if lang == "English":
        return ([
            {'label': 'Withdrawals', 'value': 'Withdrawals'},
            {'label': 'Suspensions', 'value': 'Suspensions'}
        ],
            html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }))

    else:
        return ([
            {'label': '退學', 'value': 'Withdrawals'},
            {'label': '休學', 'value': 'Suspensions'}
        ],
            html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }))

@callback(
    Output('edu-short-drp', 'children'),
    Input('lang_drp_checklist', 'value')
)
def update_checklist_options(lang):
    if lang == "English":
        df_outen = pd.read_parquet('./datas/numoutadmiss_en.parquet')
        df_resten = pd.read_parquet('./datas/numrestadmiss_en.parquet')
        
        # Filter data for the years 108 to 112 and exclude "夜二專"
        filtered_outen_df = df_outen[df_outen['退學學年'].between(108, 112) & (df_outen['Edu_Short_en'] != 'Night 2-Year Junior College')]
        filtered_resten_df = df_resten[df_resten['休學學年'].between(108, 112) & (df_resten['Edu_Short'] != 'Night 2-Year Junior College')]

        # 所有學制選項
        edu_short_options = dcc.RadioItems(
                id='edu-short-drp-radioitems',
                options=[{'label': edu_short, 'value': edu_short} for edu_short in set(filtered_outen_df['Edu_Short_en'].unique()) | set(filtered_resten_df['Edu_Short'].unique())],
                value=list(set(filtered_outen_df['Edu_Short_en'].unique()) | set(filtered_resten_df['Edu_Short'].unique()))[0],
                inline=True
            ),
        return edu_short_options

    else:
        df_out = pd.read_parquet('./datas/numoutadmiss.parquet')
        df_rest = pd.read_parquet('./datas/numrestadmiss.parquet')
        
        # Filter data for the years 108 to 112 and exclude "夜二專"
        filtered_out_df = df_out[df_out['退學學年'].between(108, 112) & (df_out['Edu_Short'] != '夜二專')]
        filtered_rest_df = df_rest[df_rest['休學學年'].between(108, 112) & (df_rest['Edu_Short'] != '夜二專')]

        # 所有學制選項
        edu_short_options = dcc.RadioItems(
                id='edu-short-drp-radioitems',
                options=[{'label': edu_short, 'value': edu_short} for edu_short in set(filtered_out_df['Edu_Short'].unique()) | set(filtered_rest_df['Edu_Short'].unique())],
                value=list(set(filtered_out_df['Edu_Short'].unique()) | set(filtered_rest_df['Edu_Short'].unique()))[0],
                inline=True
            ),
        
        return edu_short_options


@callback(
    Output('bar-chart-drp', 'children'),
    [Input('status-drp-dropdown', 'value'), Input('edu-short-drp-radioitems', 'value'),Input('lang_drp_checklist', 'value')]
)
def update_bar_charts(selected_status, selected_edu_short, lang):
    if lang == "English":
        df_outen = pd.read_parquet('./datas/numoutadmiss_en.parquet')
        df_resten = pd.read_parquet('./datas/numrestadmiss_en.parquet')
        
        # Filter data for the years 108 to 112 and exclude "夜二專"
        filtered_outen_df = df_outen[df_outen['退學學年'].between(108, 112) & (df_outen['Edu_Short_en'] != 'Night 2-Year Junior College')]
        filtered_resten_df = df_resten[df_resten['休學學年'].between(108, 112) & (df_resten['Edu_Short'] != 'Night 2-Year Junior College')]

        if selected_status == 'Withdrawals':
            filtered_df = filtered_outen_df[filtered_outen_df['Edu_Short_en'] == selected_edu_short]
        else:
            filtered_df = filtered_resten_df[filtered_resten_df['Edu_Short'] == selected_edu_short]

        if filtered_df.empty:
            raise PreventUpdate

        charts = []

        # Generate a bar chart for each '系所'
        for department in filtered_df['Department(Abbreviated)'].unique():
            dept_data = filtered_df[filtered_df['Department(Abbreviated)'] == department]
            enrollment_channel_counts = dept_data.groupby('admission pathways_short').size().reset_index(name='Count')

            if selected_status == 'Withdrawals':
                title = f'{department} Number of dropouts from the department’s admission pipeline (Academic year 108-112)'
            else:
                title = f'{department} Number of dropouts from the department’s admission pipeline (Academic year 108-112)'

            fig = px.bar(enrollment_channel_counts, x='Count', y='admission pathways_short', orientation='h',
                        title=title, labels={'Admission pathways': 'Admission pathways', 'Count': 'Number of people'})
            
            fig.update_layout(yaxis={'categoryorder': 'total ascending'})

            charts.append(html.Div(dcc.Graph(figure=fig), 
            #                        style={
            #     'overflowY':"scroll",
            #     'height':"500px",
            # }
            ))

    else:
        df_out = pd.read_parquet('./datas/numoutadmiss.parquet')
        df_rest = pd.read_parquet('./datas/numrestadmiss.parquet')
        
        # Filter data for the years 108 to 112 and exclude "夜二專"
        filtered_out_df = df_out[df_out['退學學年'].between(108, 112) & (df_out['Edu_Short'] != '夜二專')]
        filtered_rest_df = df_rest[df_rest['休學學年'].between(108, 112) & (df_rest['Edu_Short'] != '夜二專')]
    
        if selected_status == 'Withdrawals':
            filtered_df = filtered_out_df[filtered_out_df['Edu_Short'] == selected_edu_short]
        else:
            filtered_df = filtered_rest_df[filtered_rest_df['Edu_Short'] == selected_edu_short]

        if filtered_df.empty:
            raise PreventUpdate

        charts = []

        # Generate a bar chart for each '系所'
        for department in filtered_df['系所'].unique():
            dept_data = filtered_df[filtered_df['系所'] == department]
            enrollment_channel_counts = dept_data.groupby('入學管道').size().reset_index(name='Count')

            if selected_status == 'Withdrawals':
                title = f'{department} 系所的入學管道退學人數 (學年度 108-112)'
            else:
                title = f'{department} 系所的入學管道休學人數 (學年度 108-112)'

            fig = px.bar(enrollment_channel_counts, x='Count', y='入學管道', orientation='h',
                        title=title, labels={'入學管道': '入學管道', 'Count': '人數'})
            
            fig.update_layout(yaxis={'categoryorder': 'total ascending'})

            charts.append(html.Div(dcc.Graph(figure=fig), 
            #                        style={
            #     'overflowY':"scroll",
            #     'height':"500px",
            # }
            ))

    return charts
