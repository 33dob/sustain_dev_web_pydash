import pandas as pd
import dash
from dash import dcc, html, callback
from dash.dependencies import Input, Output
import plotly.express as px

dash.register_page(__name__)

lang = ["中文", 'English']


# Create Dash app

layout = html.Div([
    dcc.Link(html.Button("Home",
                style={
                    'backgroundColor':"#800080",
                    'color':"white",
                #  'marginBottom':"20px",
                    'borderRadius':"8px",
                    'borderWidth': "thin",
                    'borderStyle':"solid",
                    'borderColor':"#C6C4C4",
                    }), href="/", refresh=True),

    dcc.RadioItems(id='lang_fiverestout_checklist', 
                options=lang,
                value="中文",
                labelStyle={"margin":"0.2rem"},
                inline=True,
                style={
                    # 'marginLeft':"86%",
                    }
            ),
    #文字切換
    html.Div(id='fiverestout-title'),
    

    #文字切換
    html.Div(id='fiverestout-tab'),


    #update_edu_short_options
    dcc.RadioItems(
        id='edu-short-radioitems',
        inline=True
    ),

    #文字切換
    html.Div(id='graphs-container'),
    html.Div(id='fiverestout-team'),

])

@callback(
    Output('fiverestout-title', 'children'),
    Output('fiverestout-tab', 'children'),
    Output('fiverestout-team', 'children'),
    Input('lang_fiverestout_checklist', 'value')
)
def update_labels(lang):
    if lang == "English":
        return (
            html.H1("Comparison Chart of Main Reasons for Dropout and Suspension Over the Last Five Years"),
            dcc.Tabs(id='tabs', value='休學', children=[
                dcc.Tab(label='Suspension', value='休學'),
                dcc.Tab(label='Dropout', value='退學'),
            ]),
            html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }),
        )
    else:
        return (
            html.H1("近五年主要休退學原因比較圖"),
            dcc.Tabs(id='tabs', value='休學', children=[
                dcc.Tab(label='休學', value='休學'),
                dcc.Tab(label='退學', value='退學'),
            ]),
            html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }),
        )
    
@callback(
    Output('edu-short-radioitems', 'options'),
    Output('edu-short-radioitems', 'value'),
    [Input('tabs', 'value'),
     Input('lang_fiverestout_checklist', 'value')]
)

def update_options(selected_type,lang):
    if lang == "English":
        # Load the data
        df_xiuxue = pd.read_parquet('./datas/mainfiverest_en.parquet')
        df_tuixue = pd.read_parquet('./datas/mainfiveout_en.parquet')

        # Filter data for the years 108 to 112
        df_xiuxue_filtered = df_xiuxue[df_xiuxue['休學學年'].between(108, 112)]
        df_tuixue_filtered = df_tuixue[df_tuixue['退學學年'].between(108, 112)]

        # Group by department and reason, and count the occurrences
        xiuxue_counts = df_xiuxue_filtered.groupby(['Department(Abbreviated)', 'Reasons for Leave of Absence_short', 'Edu_short_english']).size().reset_index(name='count')
        tuixue_counts = df_tuixue_filtered.groupby(['Department(Abbreviated)', 'Reasons for Withdrawal_short', 'Edu_short_english']).size().reset_index(name='count')

        # Merge the dataframes for a combined view
        xiuxue_counts['type'] = '休學'
        tuixue_counts['type'] = '退學'
        xiuxue_counts.rename(columns={'Reasons for Leave of Absence_short': '原因'}, inplace=True)
        tuixue_counts.rename(columns={'Reasons for Withdrawal_short': '原因'}, inplace=True)
        combined_counts = pd.concat([xiuxue_counts, tuixue_counts])

        if selected_type == '退學':
            filtered_df = combined_counts[combined_counts['type'] == '退學']
        else:
            filtered_df = combined_counts[combined_counts['type'] == '休學']

        edu_short_options = [{'label': edu_short, 'value': edu_short} for edu_short in filtered_df['Edu_short_english'].unique()]
        edu_short_value = filtered_df['Edu_short_english'].unique()[0] if edu_short_options else None

    else:
        # Load the data
        df_xiuxue = pd.read_parquet('./datas/mainfiverest.parquet')
        df_tuixue = pd.read_parquet('./datas/mainfiveout.parquet')

        # Filter data for the years 108 to 112
        df_xiuxue_filtered = df_xiuxue[df_xiuxue['休學學年'].between(108, 112)]
        df_tuixue_filtered = df_tuixue[df_tuixue['退學學年'].between(108, 112)]

        # Group by department and reason, and count the occurrences
        xiuxue_counts = df_xiuxue_filtered.groupby(['系所', '休學原因', 'Edu_Short']).size().reset_index(name='count')
        tuixue_counts = df_tuixue_filtered.groupby(['系所', '退學原因', 'Edu_Short']).size().reset_index(name='count')

        # Merge the dataframes for a combined view
        xiuxue_counts['type'] = '休學'
        tuixue_counts['type'] = '退學'
        xiuxue_counts.rename(columns={'休學原因': '原因'}, inplace=True)
        tuixue_counts.rename(columns={'退學原因': '原因'}, inplace=True)
        combined_counts = pd.concat([xiuxue_counts, tuixue_counts])

        if selected_type == '退學':
            filtered_df = combined_counts[combined_counts['type'] == '退學']
        else:
            filtered_df = combined_counts[combined_counts['type'] == '休學']
        
        edu_short_options = [{'label': edu_short, 'value': edu_short} for edu_short in filtered_df['Edu_Short'].unique()]
        edu_short_value = filtered_df['Edu_Short'].unique()[0] if edu_short_options else None
    
    return edu_short_options, edu_short_value

@callback(
    Output('graphs-container', 'children'),
    [Input('tabs', 'value'),
     Input('edu-short-radioitems', 'value'),
     Input('lang_fiverestout_checklist', 'value')]
)
def update_graphs(selected_type, selected_edu_short, lang):
    if lang == "English":
        # Load the data
        df_xiuxue = pd.read_parquet('./datas/mainfiverest_en.parquet')
        df_tuixue = pd.read_parquet('./datas/mainfiveout_en.parquet')

        # Filter data for the years 108 to 112
        df_xiuxue_filtered = df_xiuxue[df_xiuxue['休學學年'].between(108, 112)]
        df_tuixue_filtered = df_tuixue[df_tuixue['退學學年'].between(108, 112)]

        # Group by department and reason, and count the occurrences
        xiuxue_counts = df_xiuxue_filtered.groupby(['Department(Abbreviated)', 'Reasons for Leave of Absence_short', 'Edu_short_english']).size().reset_index(name='count')
        tuixue_counts = df_tuixue_filtered.groupby(['Department(Abbreviated)', 'Reasons for Withdrawal_short', 'Edu_short_english']).size().reset_index(name='count')

        # Merge the dataframes for a combined view
        xiuxue_counts['type'] = '休學'
        tuixue_counts['type'] = '退學'
        xiuxue_counts.rename(columns={'Reasons for Leave of Absence_short': '原因'}, inplace=True)
        tuixue_counts.rename(columns={'Reasons for Withdrawal_short': '原因'}, inplace=True)
        combined_counts = pd.concat([xiuxue_counts, tuixue_counts])

        if selected_type == '退學':
            filtered_df = combined_counts[(combined_counts['type'] == '退學') &
                                        (combined_counts['Edu_short_english'] == selected_edu_short)]
            title = 'Dropout Reasons Comparison Chart'
        else:
            filtered_df = combined_counts[(combined_counts['type'] == '休學') &
                                        (combined_counts['Edu_short_english'] == selected_edu_short)]
            title = 'Suspension Reasons Comparison Chart'

        department_list = filtered_df['Department(Abbreviated)'].unique()
        graphs = []

        for department in department_list:
            department_df = filtered_df[filtered_df['Department(Abbreviated)'] == department]
            grouped_df = department_df.groupby(['原因']).size().reset_index(name='Count')

            # 顯示前十名原因
            grouped_df = grouped_df.nlargest(10, 'Count')

            # Calculate appropriate font size based on the maximum length of labels
            max_label_length = max(grouped_df['原因'].apply(len))
            font_size = max(12, min(20, 120 // max_label_length))

            fig = px.pie(grouped_df, names='原因', values='Count',
                        title=f'{department} {title} (Academic Years 108~112)',
                        color_discrete_sequence=px.colors.qualitative.Set3)

            # 更新 traces
            fig.update_traces(
                textinfo='percent+label',
                texttemplate='%{label}<br>%{percent} (%{value}人)',
                marker=dict(line=dict(color='#000000', width=2)),
                textposition='inside',
                textfont_size=font_size,  # Adjust font size dynamically
                automargin=True,  # Allow text to auto-margin to avoid overlaps
                insidetextorientation='horizontal'  # Horizontal text orientation
            )

            graphs.append(html.Div(dcc.Graph(figure=fig), style={'margin-bottom': '20px'}))
    else:
        # Load the data
        df_xiuxue = pd.read_parquet('./datas/mainfiverest.parquet')
        df_tuixue = pd.read_parquet('./datas/mainfiveout.parquet')

        # Filter data for the years 108 to 112
        df_xiuxue_filtered = df_xiuxue[df_xiuxue['休學學年'].between(108, 112)]
        df_tuixue_filtered = df_tuixue[df_tuixue['退學學年'].between(108, 112)]

        # Group by department and reason, and count the occurrences
        xiuxue_counts = df_xiuxue_filtered.groupby(['系所', '休學原因', 'Edu_Short']).size().reset_index(name='count')
        tuixue_counts = df_tuixue_filtered.groupby(['系所', '退學原因', 'Edu_Short']).size().reset_index(name='count')

        # Merge the dataframes for a combined view
        xiuxue_counts['type'] = '休學'
        tuixue_counts['type'] = '退學'
        xiuxue_counts.rename(columns={'休學原因': '原因'}, inplace=True)
        tuixue_counts.rename(columns={'退學原因': '原因'}, inplace=True)
        combined_counts = pd.concat([xiuxue_counts, tuixue_counts])

        if selected_type == '退學':
            filtered_df = combined_counts[(combined_counts['type'] == '退學') &
                                        (combined_counts['Edu_Short'] == selected_edu_short)]
            title = '退學原因比較圖'
        else:
            filtered_df = combined_counts[(combined_counts['type'] == '休學') &
                                        (combined_counts['Edu_Short'] == selected_edu_short)]
            title = '休學原因比較圖'

        department_list = filtered_df['系所'].unique()
        graphs = []

        for department in department_list:
            department_df = filtered_df[filtered_df['系所'] == department]
            grouped_df = department_df.groupby(['原因']).size().reset_index(name='Count')

            # 顯示前十名原因
            grouped_df = grouped_df.nlargest(10, 'Count')

            fig = px.pie(grouped_df, names='原因', values='Count', 
                        title=f'{department} {title} (學年度 108~112)',
                        color_discrete_sequence=px.colors.qualitative.Set3)
            
            # 更新 traces
            fig.update_traces(textinfo='label+value', 
                            texttemplate='%{label}: %{value} 人', 
                            marker=dict(line=dict(color='#000000', width=2)),
                            textposition='inside',
                            hovertemplate='<b>%{label}</b>: %{value} 人<extra></extra>')

            graphs.append(html.Div(dcc.Graph(figure=fig), style={'margin-bottom': '20px'}))

    return graphs