import dash
import pandas as pd
import plotly.express as px
from dash import callback, dcc, html
from dash.dependencies import Input, Output

dash.register_page(__name__)

df = pd.read_parquet('./datas/enrollnum.parquet')

# 獲取所有學年度(Get all academic years)
available_years = df['End_Year'].unique().tolist()

lang = ["中文", 'English']

# 設定佈局 (Set layout)
layout = html.Div([
    dcc.Link(html.Button("Home",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/", refresh=True),
                                 
    dcc.RadioItems(id='lang_entrypath_checklist', 
                       options=lang,
                       value="中文",
                       labelStyle={"margin":"0.2rem"},
                       inline=True,
                       style={
                           # 'marginLeft':"86%",
                            }
                    ),

    html.Div(id='title-div'),
    # html.H2("Sankey Diagram between Entry Path, Gender, and College"),  # 英文標題 (English Title)
    html.H4("來源資料:畢業流向問卷(Source: Graduate Destination Survey)"),
    html.Div(id='Academic-div'),

    dcc.Dropdown(
        id='year-dropdown',
        options=[{'label': year, 'value': year} for year in available_years],
        value=available_years[0],  # 預設選擇第一個學年度 (Default select the first academic year)
        clearable=False
    ),

    html.Div(id='Entrypath-div'),

    dcc.RadioItems(
        id='top-entry-select',
        options=[
            {'label': '前5項(Top 5)', 'value': 5},  # Top 5
            {'label': '前10項(Top 10)', 'value': 10}  # Top 10
        ],
        value=5,  # Default to top 5
        labelStyle={'display': 'block'}
    ),

    dcc.Graph(id='parallel-categories-graph'),

    html.Div(id='entrypathgender-team'),
    # html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
    #            style={
    #                'marginTop' : "10px",
    #                'textAlign' : "center",
    #                }),
])


@callback(
    [Output('title-div', 'children'), Output('Academic-div', 'children'), Output('Entrypath-div', 'children'),
    Output('entrypathgender-team', 'children')],
    [Input('lang_entrypath_checklist', 'value')]
)
def update_labels(lang):
    if lang == "English":
        return (
            html.H1("Sankey Diagram between Entry Path, Gender, and College"),
            html.Label("Select Academic Year:"),
            html.Label("Entry Path Selection:"),
            html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
        )
    else:
        return (
            html.H1("入學管道、性別與學院之間的桑基圖"),
            html.Label("選取學年度:"),
            html.Label("選取入學管道:"),
            html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
        )

@callback(
    Output('top-entry-select', 'options'),
    [Input('lang_entrypath_checklist', 'value')]
)
def update_top_entry_labels(lang):
    if lang == "English":
        return [
            {'label': 'Top 5', 'value': 5},
            {'label': 'Top 10', 'value': 10}
        ]
    else:
        return [
            {'label': '前5項', 'value': 5},
            {'label': '前10項', 'value': 10}
        ]

# 設置回調函數 (Set callback function)
@callback(
    Output('parallel-categories-graph', 'figure'),
    [Input('lang_entrypath_checklist', 'value'),Input('year-dropdown', 'value'), Input('top-entry-select', 'value')]
)

def update_parallel_categories(select, selected_year, top_n):
    if select == "English":

        df = pd.read_parquet('./datas/enrollnum_en.parquet')
        # 根據選定的學年度過濾資料 (Filter data based on selected academic year)
        filtered_df = df[df['End_Year'] == selected_year]

        # 計算各分類的人數 (Calculate the count for each category)
        entry_counts = filtered_df.groupby(['Entry_Duct_Name_Abbreviated'])['End_Year'].size().reset_index(name='Count')
        top_entries = entry_counts.nlargest(top_n, 'Count')['Entry_Duct_Name_Abbreviated']
        filtered_df = filtered_df[filtered_df['Entry_Duct_Name_Abbreviated'].isin(top_entries)]

        filtered_df['Count'] = filtered_df.groupby(['Entry_Duct_Name_Abbreviated', 'sex_en', 'school_short'])['End_Year'].transform('count')

        # 生成平行類別圖 (Generate parallel categories plot)
        fig = px.parallel_categories(
            filtered_df,
            dimensions=['Entry_Duct_Name_Abbreviated', 'sex_en', 'school_short'],
            color="Count",  # 根據計算出來的人數設置顏色 (Color coded by calculated counts)
            color_continuous_scale=px.colors.sequential.Inferno,
            labels={
                'Entry_Duct_Name_Abbreviated': 'Entry Path',  # Entry Path Name
                'sex_en': 'Gender',  # Gender
                'school_short': 'College',  # College
                'Count': 'Headcount'  # Headcount
            }
    )
        # 更新圖表標題 (Update chart title)
        fig.update_layout(
            title_text=f"Sankey Diagram between Entry Path, Gender, and School - {selected_year} Academic Year",
            font_size=10
        )
    else:
        df = pd.read_parquet('./datas/enrollnum.parquet')
        # 根據選定的學年度過濾資料 (Filter data based on selected academic year)
        filtered_df = df[df['End_Year'] == selected_year]

        # 計算各分類的人數 (Calculate the count for each category)
        entry_counts = filtered_df.groupby(['Entry_Duct_Name'])['End_Year'].size().reset_index(name='Count')
        top_entries = entry_counts.nlargest(top_n, 'Count')['Entry_Duct_Name']
        filtered_df = filtered_df[filtered_df['Entry_Duct_Name'].isin(top_entries)]

        filtered_df['Count'] = filtered_df.groupby(['Entry_Duct_Name', 'Sex', 'Institute'])['End_Year'].transform('count')

        # 生成平行類別圖 (Generate parallel categories plot)
        fig = px.parallel_categories(
            filtered_df,
            dimensions=['Entry_Duct_Name', 'Sex', 'Institute'],
            color="Count",  # 根據計算出來的人數設置顏色 (Color coded by calculated counts)
            color_continuous_scale=px.colors.sequential.Inferno,
            labels={
                'Entry_Duct_Name': '入學管道名稱 (Entry Path)',  # Entry Path Name
                'Sex': '性別 (Gender)',  # Gender
                'Institute': '學院 (College)',  # College
                'Count': '人數 (Headcount)'  # Headcount
            }
    )

    return fig
