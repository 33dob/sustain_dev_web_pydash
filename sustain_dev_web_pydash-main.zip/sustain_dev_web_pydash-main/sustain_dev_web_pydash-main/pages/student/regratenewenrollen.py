import dash
from dash import dcc, html, callback
from dash.dependencies import Input, Output
import plotly.graph_objects as go
import pandas as pd

data = pd.read_parquet('./datas/regratenewenroll.parquet')

dash.register_page(__name__)

# Check the year column
data['Academic Year'] = data['學年度'].astype(str).str.extract('(\d+)', expand=False).astype(int)

# Mapping for translations
day_night_mapping = {
    '日間': 'Daytime',
    '進修': 'Evening',
    '在職': 'On-the-Job'
}

program_mapping = {
    '學士班(含四技)': 'Bachelor (including 4-year program)',
    '二年制大學(二技)': '2-Year College(2-Year Program)',
    '五專': '5-Year College',
    '碩士班': 'Master',
    '博士班': 'PhD',
    '二專': '2-Year Program'
}

department_mapping = {
    '數位多媒體設計系': 'Department of Digital Media Design',
    '商品創意經營系': 'Department of Creative Product Design',
    '應用外語科': 'Department of Applied Foreign Languages',
    '會計資訊系': 'Department of Accounting Information',
    '會計資訊系會計財稅碩士班': 'Master Program in Accounting and Taxation',
    '財務金融系': 'Department of Finance',
    '財務金融系碩士班': 'Master Program in Finance',
    '財政稅務系': 'Department of Public Finance and Tax Administration',
    '財政稅務系碩士班': 'Master Program in Public Finance and Tax Administration',
    '企業管理系': 'Department of Business Administration',
    '企業管理系碩士班': 'Master Program in Business Administration',
    '國際商務系': 'Department of International Business',
    '國際商務系碩士班': 'Master Program in International Business',
    '商業設計管理系': 'Department of Commercial Design and Management',
    '貿易實務法律暨談判碩士學位學程': 'Master Program in Trade Practices and Negotiation',
    '資訊管理系': 'Department of Information Management',
    '資訊與決策科學研究所': 'Institute of Information and Decision Sciences',
    '創意設計與經營管理研究所': 'Graduate Institute of Creative Design and Management',
    '財經學院博士班': 'PhD Program in Finance',
    '創意科技與產品設計系': 'Department of Creative Technology and Product Design',
    '創意設計與經營學科學士學位學程': 'Bachelor Program in Creative Design and Management',
    '資訊管理系人工智慧與商業應用碩士班': 'Master Program in Artificial Intelligence and Business Applications',
    '財務金融系科技創新服務碩士在職專班': 'In-Service Master Program in Financial Technology and Innovation',
    '會計資訊系會計財稅碩士班(原為會計資訊系會計財稅碩士班)': 'Master Program in Accounting and Taxation (formerly Master Program in Accounting and Taxation)'
}

# Apply mappings
data['日間/進修'] = data['日間/進修'].map(day_night_mapping)  # Daytime/Evening
data['學制班別'] = data['學制班別'].map(program_mapping)  # Program Type
data['系所名稱'] = data['系所名稱'].map(department_mapping)  # Department Name

# Remove any rows where mapping resulted in NaN
data = data.dropna(subset=['日間/進修', '學制班別', '系所名稱'])

# Filter the required columns
filtered_data = data[['學年度', '系所名稱', '日間/進修', '學制班別',
                      '當學年度總量內核定新生招生名額(A)', '當學年度新生保留入學資格人數(B)',
                      '當學年度總量內新生招生核定名額之實際註冊人數(C)', '當學年度各學系境外(新生)學生實際註冊人數 (E)',
                      '當學年度新生註冊率(%)D=〔(C+E)/(A-B+E)〕＊100％']]
# Column translations
# '學年度' -> 'Academic Year'
# '系所名稱' -> 'Department Name'
# '日間/進修' -> 'Day/Evening'
# '學制班別' -> 'Program Type'
# '當學年度總量內核定新生招生名額(A)' -> 'Approved Enrollment Quota for New Students (A)'
# '當學年度新生保留入學資格人數(B)' -> 'Number of New Students Deferring Admission (B)'
# '當學年度總量內新生招生核定名額之實際註冊人數(C)' -> 'Actual Enrollment Number within Quota (C)'
# '當學年度各學系境外(新生)學生實際註冊人數 (E)' -> 'Actual Enrollment Number of International New Students (E)'
# '當學年度新生註冊率(%)D=〔(C+E)/(A-B+E)〕＊100％' -> 'New Student Enrollment Rate (%) D=〔(C+E)/(A-B+E)〕＊100％'

def create_checklist(id, options, all_selected):
    return html.Div([
        dcc.Checklist(
            id=id,
            options=[{'label': 'Select All', 'value': 'all'}] + [{'label': opt, 'value': opt} for opt in options],
            value=['all'] + list(all_selected) if len(all_selected) > 0 else [],
            labelStyle={'display': 'inline-block'}
        ),
    ])

layout = html.Div([
    dcc.Link(html.Button("Home",
                            style={
                                'backgroundColor':"#800080",
                                'color':"white",
                                'marginBottom':"20px",
                                'borderRadius':"8px",
                                'borderWidth': "thin",
                                'borderStyle':"solid",
                                'borderColor':"#C6C4C4",
                                }), href="/", refresh=True),
    dcc.Link(html.Button("中文",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/student/regratenewenroll", refresh=True),

    dcc.Link(html.Button("英文",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/student/regratenewenrollen", refresh=True),
    html.H1("New Student Enrollment Numbers and Enrollment Rates by Department and Academic Year"),
    html.Div([
        html.Label("Select Day/Evening:"),
        create_checklist('day-night-selector-en', list(filtered_data['日間/進修'].unique()), list(filtered_data['日間/進修'].unique()))
    ]),
    html.Div([
        html.Label("Select Program Type:"),
        create_checklist('program-selector-en', list(filtered_data['學制班別'].unique()), list(filtered_data['學制班別'].unique()))
    ]),
    html.Div([
        html.Label("Select Department:"),
        create_checklist('department-selector-en', list(filtered_data['系所名稱'].unique()), list(filtered_data['系所名稱'].unique()))
    ]),
    dcc.Graph(id='stacked-bar-line-chart-en'),
    html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   }),
])

def update_checklist(selected_options, all_options):
    if 'all' in selected_options:
        if len(selected_options) == 1:
            return ['all'] + list(all_options)
        else:
            return []
    return selected_options

@callback(
    Output('stacked-bar-line-chart-en', 'figure'),
    [
        Input('day-night-selector-en', 'value'),
        Input('program-selector-en', 'value'),
        Input('department-selector-en', 'value')
    ]
)
def update_chart(selected_day_night, selected_programs, selected_departments):
    selected_day_night = [opt for opt in selected_day_night if opt != 'all']
    selected_programs = [opt for opt in selected_programs if opt != 'all']
    selected_departments = [opt for opt in selected_departments if opt != 'all']

    filtered = filtered_data[
        (filtered_data['日間/進修'].isin(selected_day_night)) &  # Daytime/Evening
        (filtered_data['學制班別'].isin(selected_programs)) &  # Program Type
        (filtered_data['系所名稱'].isin(selected_departments))  # Department Name
    ]

    fig = go.Figure()

    color_pairs = [
        ('#1f77b4', '#aec7e8'),  # Dark blue and light blue
        ('#ff7f0e', '#ffbb78'),  # Dark orange and light orange
        ('#2ca02c', '#98df8a'),  # Dark green and light green
        ('#d62728', '#ff9896'),  # Dark red and pink
        ('#9467bd', '#c5b0d5'),  # Dark purple and light purple
        ('#8c564b', '#c49c94'),  # Dark brown and light brown
        ('#e377c2', '#f7b6d2'),  # Dark pink and light pink
        ('#7f7f7f', '#c7c7c7'),  # Dark gray and light gray
        ('#bcbd22', '#dbdb8d'),  # Dark yellow and light yellow
        ('#17becf', '#9edae5')  # Dark cyan and light cyan
    ]

    for i, department in enumerate(filtered['系所名稱'].unique()):  # Department Name
        department_data = filtered[filtered['系所名稱'] == department]
        color = color_pairs[i % len(color_pairs)]
        fig.add_trace(go.Bar(
            x=department_data['學年度'],  # Academic Year
            y=department_data['當學年度總量內新生招生核定名額之實際註冊人數(C)'],  # Actual Enrollment Number within Quota (C)
            name=department,
            text=department_data['當學年度總量內新生招生核定名額之實際註冊人數(C)'],
            hovertemplate='<b>%{x}</b><br>Enrollment Number: %{y}<extra></extra>',
            textposition='auto',
            marker_color=color[0]
        ))
        fig.add_trace(go.Scatter(
            x=department_data['學年度'],  # Academic Year
            y=department_data['當學年度新生註冊率(%)D=〔(C+E)/(A-B+E)〕＊100％'],  # New Student Enrollment Rate (%) D
            mode='lines+markers',
            name=f'{department} Enrollment Rate',
            yaxis='y2',
            line=dict(color=color[1])
        ))

    # Set chart layout
    fig.update_layout(
        title='New Student Enrollment Numbers and Enrollment Rates by Department and Academic Year',
        xaxis=dict(title='Academic Year', tickmode='linear'),
        yaxis=dict(title='New Student Enrollment Numbers'),
        yaxis2=dict(title='New Student Enrollment Rate (%)', overlaying='y', side='right'),
        barmode='group',
        legend=dict(x=0.5, y=-0.2, orientation='h'),  # Move legend to the bottom center
    )

    return fig

@callback(
    Output('program-selector-en', 'options'),
    [Input('day-night-selector-en', 'value')]
)
def update_program_selector_options(selected_day_night):
    selected_day_night = [opt for opt in selected_day_night if opt != 'all']
    filtered = filtered_data[filtered_data['日間/進修'].isin(selected_day_night)]  # Daytime/Evening
    program_options = [{'label': program, 'value': program} for program in filtered['學制班別'].unique()]  # Program Type
    return [{'label': 'Select All', 'value': 'all'}] + program_options

@callback(
    Output('program-selector-en', 'value'),
    [Input('program-selector-en', 'options'), Input('program-selector-en', 'value')]
)
def update_program_selector_value(program_options, selected_programs):
    all_programs = [opt['value'] for opt in program_options if opt['value'] != 'all']
    return update_checklist(selected_programs, all_programs)

@callback(
    Output('department-selector-en', 'options'),
    [Input('day-night-selector-en', 'value'), Input('program-selector-en', 'value')]
)
def update_department_selector_options(selected_day_night, selected_programs):
    selected_day_night = [opt for opt in selected_day_night if opt != 'all']
    selected_programs = [opt for opt in selected_programs if opt != 'all']
    filtered = filtered_data[
        (filtered_data['日間/進修'].isin(selected_day_night)) &  # Daytime/Evening
        (filtered_data['學制班別'].isin(selected_programs))  # Program Type
    ]
    department_options = [{'label': dept, 'value': dept} for dept in filtered['系所名稱'].unique()]  # Department Name
    return [{'label': 'Select All', 'value': 'all'}] + department_options

@callback(
    Output('department-selector-en', 'value'),
    [Input('department-selector-en', 'options'), Input('department-selector-en', 'value')]
)
def update_department_selector_value(department_options, selected_departments):
    all_departments = [opt['value'] for opt in department_options if opt['value'] != 'all']
    return update_checklist(selected_departments, all_departments)

@callback(
    Output('day-night-selector-en', 'value'),
    [Input('day-night-selector-en', 'value')]
)
def update_day_night_selector(selected_options):
    all_options = filtered_data['日間/進修'].unique().tolist()  # Daytime/Evening
    return update_checklist(selected_options, all_options)