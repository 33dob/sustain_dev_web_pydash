import dash
import pandas as pd
import plotly.express as px
from dash import dcc, callback, html, Input, Output, ctx

dash.register_page(__name__)

lang = ["中文", 'English']

df = pd.read_parquet('./datas/departnum_en.parquet')

layout = html.Div([
    html.Div([
        dcc.Link(html.Button("Home",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/", refresh=True),
        
        dcc.RadioItems(id='lang_dist_checklist', 
                    options=lang,
                    value="中文",
                    labelStyle={"margin":"0.2rem"},
                    inline=True,
                    style={
                        # 'marginLeft':"86%",
                        }
                ),
        # dcc.Link(html.Button("中漢語",
        #                      id="jongwen",
        #                      style={
        #                          'backgroundColor':"#800080",
        #                          'color':"white",
        #                          'marginBottom':"20px",
        #                          'marginLeft':"85%",
        #                          'borderRadius':"8px",
        #                          'borderWidth': "thin",
        #                          'borderStyle':"solid",
        #                          'borderColor':"#C6C4C4",
        #                          }), href=""),
        # dcc.Link(html.Button("English",
        #                      id="eng",
        #                      style={
        #                          'backgroundColor':"#800080",
        #                          'color':"white",
        #                          'marginBottom':"20px",
        #                          'marginLeft':"5px",
        #                          'borderRadius':"8px",
        #                          'borderWidth': "thin",
        #                          'borderStyle':"solid",
        #                          'borderColor':"#C6C4C4",
        #                          }), href=""),
        
        dcc.Dropdown(
                id='year-dist-dropdown',
                options=[{'label': year, 'value': year} for year in df['Years'].unique()],
                value=df['Years'].unique()[0],
                clearable=False,
                style={
                    'marginBottom':"8px",
                }
            ),
        dcc.Graph(id="sunburst-chart", style={
                'height':"450px",}),

        html.Div(id='stddistbyyear-team')
        
    ])
])


@callback(
    Output("sunburst-chart", "figure"),
    Output("stddistbyyear-team", "children"),
    [Input('lang_dist_checklist', 'value'),
     Input("year-dist-dropdown", "value")]
)


def AcademicYearChart(select, selected_year):
    if select == "English":
        df = pd.read_parquet('./datas/departnum_en.parquet')
        
        filtered_df = df[df['Years'] == selected_year]
        student_counts = filtered_df.groupby(['Edu_Short_english', 'Department(Abbreviated)']).size().reset_index(name='Count')
        fig = px.sunburst(student_counts, path=['Edu_Short_english', 'Department(Abbreviated)'], values='Count',
                        title=f'Student Distribution for Academic Year {selected_year}' 
                        )
        fig.update_layout(
            margin = dict(t=30, l=25, r=25, b=10)
        )
        team = html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'textAlign' : "center",
                   'marginTop' : "30px",
                   }),  
    else:
        df = pd.read_parquet('./datas/departnum.parquet')
        
        filtered_df = df[df['Years'] == selected_year]
        student_counts = filtered_df.groupby(['Edu_Short', 'department_chinese']).size().reset_index(name='Count')
        fig = px.sunburst(student_counts, path=['Edu_Short', 'department_chinese'], values='Count', 
                        title=f'{selected_year} 學年學生分佈'
                        )
        fig.update_layout(
            margin = dict(t=30, l=25, r=25, b=10)
        )
        team = html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
    return (fig, team)




