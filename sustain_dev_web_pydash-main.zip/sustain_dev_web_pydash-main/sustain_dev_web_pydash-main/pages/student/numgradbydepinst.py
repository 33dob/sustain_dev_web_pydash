import dash
import pandas as pd
import plotly.express as px
from dash import dcc, html, callback
from dash.dependencies import Input, Output

dash.register_page(__name__)

data = pd.read_parquet('./datas/graddepartnum.parquet')

lang = ["中文", 'English']

layout = html.Div([
    dcc.Link(html.Button("Home",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/", refresh=True),
    
    dcc.RadioItems(id='lang_depinst_checklist', 
                    options=lang,
                    value="中文",
                    labelStyle={"margin":"0.2rem"},
                    inline=True,
                    style={
                        # 'marginLeft':"86%",
                        }
                ),

    dcc.Graph(id='depinst-chart'),

    html.Div(id='depinst-team'),
    # html.P("Teamwork by Sandy, Emily, Debbie, and Ilham , directed by Prof. Ching-Shih Tsou. All rights reserved",
    #            style={
    #                'marginTop' : "10px",
    #                'textAlign' : "center",
    #                }),
])

# 依照語言調整科系文字
@callback(
    Output('depinst-chart', 'figure'),
    Output('depinst-team', 'children'),
    Input('lang_depinst_checklist', 'value')
)
def update_labels_chart(lang):
    if lang == "English":

        graduated_data = data[data['Status'] == '畢業']
        organized_data = graduated_data[['Dept_Short_en', 'End_Year', 'Edu_Short_en', '畢業滿_年']]
        grad_counts = organized_data.groupby(['Dept_Short_en', 'Edu_Short_en', '畢業滿_年']).size().reset_index(name='畢業人數')
        graduated_data = data[data['Status'] == '畢業']
        organized_data = graduated_data[['Dept_Short_en', 'Edu_Short_en', '畢業滿_年']]
        grad_counts = organized_data.groupby(['Dept_Short_en', 'Edu_Short_en']).size().reset_index(name='畢業人數')
        sorted_grad_counts = grad_counts.sort_values(by=['Edu_Short_en', '畢業人數'], ascending=[True, False])

        # 創建分組長條圖
        fig = px.bar(sorted_grad_counts, 
                        x='Dept_Short_en', 
                        y='畢業人數', 
                        color='Edu_Short_en',
                        title='Distribution of Graduates by Department',
                        labels={'畢業人數': 'Number of Graduates', 'Dept_Short_en': 'Department', 'Edu_Short_en': 'Education System'},
                        height=600, 
                        width=1000)
        
        team = html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
        return fig, team
    else:
        graduated_data = data[data['Status'] == '畢業']
        organized_data = graduated_data[['Dept_Short', 'End_Year', 'Edu_Short', '畢業滿_年']]
        grad_counts = organized_data.groupby(['Dept_Short', 'Edu_Short', '畢業滿_年']).size().reset_index(name='畢業人數')
        graduated_data = data[data['Status'] == '畢業']
        organized_data = graduated_data[['Dept_Short', 'Edu_Short', '畢業滿_年']]
        grad_counts = organized_data.groupby(['Dept_Short', 'Edu_Short']).size().reset_index(name='畢業人數')
        sorted_grad_counts = grad_counts.sort_values(by=['Edu_Short', '畢業人數'], ascending=[True, False])

        # 創建分組長條圖
        fig = px.bar(sorted_grad_counts, 
                        x='Dept_Short', 
                        y='畢業人數', 
                        color='Edu_Short',
                        title='各系所畢業人數分布',
                        labels={'畢業人數': '人數', 'Dept_Short': '系所', 'Edu_Short': '學制'},
                        height=600, 
                        width=1000)
        team = html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
        return fig, team
    
