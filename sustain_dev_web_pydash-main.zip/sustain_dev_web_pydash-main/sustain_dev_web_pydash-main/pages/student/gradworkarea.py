import dash
from dash import dcc, html, callback
from dash.dependencies import Input, Output
import plotly.express as px
import pandas as pd
import json, requests

dash.register_page(__name__)

geojson_path = r'./datas/taiwanjson.json'

with open(geojson_path, encoding='utf-8') as f:
    geojson = json.load(f)

data = pd.read_parquet('./datas/gradworkcity.parquet')

data_count = data.groupby(['工作所在地點_境內區域', '畢業滿_年']).size().reset_index(name='Count')

lang = ["中文", 'English']

# 應用的布局
layout = html.Div([
    dcc.Link(html.Button("Home",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/", refresh=True),

    dcc.RadioItems(id='lang_workarea_checklist', 
                    options=lang,
                    value="中文",
                    labelStyle={"margin":"0.2rem"},
                    inline=True,
                    style={
                        # 'marginLeft':"86%",
                        }
                ),
    html.Div(id='year-dropdownlist'),

    dcc.Graph(id='bar-graph'),
    dcc.Graph(id='map-graph'),
    html.Div(id='gradworkarea-team')
    # html.P("Teamwork by Sandy, Emily, Debbie, and Ilham , directed by Prof. Ching-Shih Tsou. All rights reserved",
    #            style={
    #                'marginTop' : "10px",
    #                'textAlign' : "center",
    #                }),
    
])
# Callbacks Dropdown文字
@callback(
    Output('year-dropdownlist', 'children'),
    Output('gradworkarea-team', 'children'),
    Input('lang_workarea_checklist', 'value')
)

def update_labels(lang):
    if lang == "English":
        data = pd.read_parquet('./datas/gradworkcity_en.parquet')
        data_count = data.groupby(['area', 'Graduation_years']).size().reset_index(name='Count')
        dropdown = dcc.Dropdown(
                id='year-dropdown',
                options=[{'label': f"{year} years later", 'value': year} for year in sorted(data_count['Graduation_years'].unique())],
                value=sorted(data_count['Graduation_years'].unique())[0])  # 預設選項
        team = html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
        return dropdown,team
    else:
        data = pd.read_parquet('./datas/gradworkcity.parquet')
        data_count = data.groupby(['工作所在地點_境內區域', '畢業滿_年']).size().reset_index(name='Count')
        dropdown = dcc.Dropdown(
                id='year-dropdown',
                options=[{'label': f"{year} 年後", 'value': year} for year in sorted(data_count['畢業滿_年'].unique())],
                value=sorted(data_count['畢業滿_年'].unique())[0])
        team = html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
        return dropdown, team
 

# Callbacks 更新地圖和柱狀圖
@callback(
    [Output('map-graph', 'figure'),
     Output('bar-graph', 'figure')],
    [Input('year-dropdown', 'value'),
     Input('lang_workarea_checklist', 'value')]
)
def update_content(selected_year, lang):
    if lang == "English":
        data = pd.read_parquet('./datas/gradworkcity_en.parquet')
        data_count = data.groupby(['area', 'Graduation_years']).size().reset_index(name='Count')

        filtered_data = data_count[data_count['Graduation_years'] == selected_year]
        
        # 更新地圖
        map_fig = px.scatter_geo(filtered_data,
                                geojson=geojson,
                                locations='area',
                                featureidkey='properties.name',
                                color='Count',
                                size='Count',
                                projection='mercator',
                                hover_name='area',
                                hover_data={'Graduation_years': True, 'Count': True})
        map_fig.update_geos(fitbounds="locations")
        
        # 更新柱狀圖，按人數由多到少排序
        bar_fig = px.bar(filtered_data.sort_values(by='Count', ascending=False),
                        x='Count',
                        y='area',
                        color='Count',
                        orientation='h',
                        title=f'Number of people working in each county or city {selected_year} after graduation')
        bar_fig.update_layout(margin=dict(l=200), yaxis=dict(tickfont=dict(size=10)),
                            yaxis_title="County and city", xaxis_title="Number of people")
        
    else:
        data = pd.read_parquet('./datas/gradworkcity.parquet')

        data_count = data.groupby(['工作所在地點_境內區域', '畢業滿_年']).size().reset_index(name='Count')

        filtered_data = data_count[data_count['畢業滿_年'] == selected_year]
        
        # 更新地圖
        map_fig = px.scatter_geo(filtered_data,
                                geojson=geojson,
                                locations='工作所在地點_境內區域',
                                featureidkey='properties.name',
                                color='Count',
                                size='Count',
                                projection='mercator',
                                hover_name='工作所在地點_境內區域',
                                hover_data={'畢業滿_年': True, 'Count': True})
        map_fig.update_geos(fitbounds="locations")
        
        # 更新柱狀圖，按人數由多到少排序
        bar_fig = px.bar(filtered_data.sort_values(by='Count', ascending=False),
                        x='Count',
                        y='工作所在地點_境內區域',
                        color='Count',
                        orientation='h',
                        title=f'畢業後{selected_year}年在各縣市工作的人口數')
        bar_fig.update_layout(margin=dict(l=200), yaxis=dict(tickfont=dict(size=10)),
                            yaxis_title="縣市", xaxis_title="人數")

    return map_fig, bar_fig

