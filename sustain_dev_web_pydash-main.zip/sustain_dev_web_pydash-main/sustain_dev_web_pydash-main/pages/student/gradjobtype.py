import pandas as pd
import dash
from dash import callback, dcc, html, no_update
from dash.dependencies import Input, Output
import plotly.express as px

dash.register_page(__name__)

all_option = {
    '中文' : ['金融財務類','教育與訓練類','行銷與銷售類','政府公共事務類','製造業','企業經營管理類','個人及社會服務類','醫療保健類','建築營造業',
            '物流運輸類','司法、法律與公共安全類','休閒與觀光旅遊類','資訊科技類','科學、技術、工程、數學類','藝文與影音傳播類','天然資源、食品與農業類'],
    'English' : ["Financial Services","Education and Training","Marketing and Sales","Government and Public Affairs","Manufacturing","Business Management",
                 "Personal and Social Services","Healthcare","Construction","Logistics and Transportation","Justice, Law, and Public Safety","Leisure and Tourism",
                 "Information Technology","Science, Technology, Engineering, and Mathematics (STEM)","Arts, Culture, and Media","Natural Resources, Food, and Agriculture"],
}

# Define the contents of the option card
layout = html.Div([
    dcc.Link(html.Button("Home",
                             style={
                                 'backgroundColor':"#800080",
                                 'color':"white",
                                 'marginBottom':"20px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 }), href="/", refresh=True),
    
    dcc.RadioItems(id='lang_jobtype_checklist', 
                       options=[{'label':k, 'value':k} for k in all_option.keys()],
                       value="中文",
                       labelStyle={"margin":"0.2rem"},
                       inline=True,
                       style={
                            'marginTop':"5px",
                            # 'marginLeft':"86%",
                            }
                    ),

    html.Div(id='job-title-div'),
    html.Div(id='job-div'),

    html.Div([
        dcc.Checklist(
            id='job-types',
            # options=checklist_options,
            value=[],#[checklist_options[0]['value']] ,
            labelStyle={"margin":"0.2rem"},
            inline=True,
            style = {
                 'marginTop':"10px"
             }
        )
    ]),

    dcc.Tabs(id='tabs-job-type', value='1年', children=[
        dcc.Tab(label='畢業滿1年', value='1年'),#Graduated for 1 year
        dcc.Tab(label='畢業滿3年', value='3年'), #Graduated for 3 year
        # No information for 5 years after graduation
    ]),

    html.Div(id='tabs-content-job-type'),

    html.Div(id='gradjobtype-team')
    # html.P("Teamwork by Sandy, Emily, Debbie, and Ilham , directed by Prof. Ching-Shih Tsou. All rights reserved",
    #            style={
    #                'marginTop' : "10px",
    #                'textAlign' : "center",
    #                }),
])

@callback(
    [Output('job-title-div', 'children'), Output('job-div', 'children'),
    Output('gradjobtype-team', 'children')],
    [Input('lang_jobtype_checklist', 'value')]
)
def update_labels(lang):
    if lang == "English":
        return (
            html.H4("Banner Chart of Graduation Employment Types by Faculty"),
            html.Label("Type of work occupation:"),
            html.P("Teamwork by Meng-Shan Tsai, Yung-Hsu Chang. , Yun-Shan Li. , and Ilham, directed by Prof. Ching-Shih Tsou. All rights reserved.",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
        )
    else:
        return (
            html.H4("各學院畢業就業類型"),
            html.Label("工作職業類型:"),
            html.P("開發團隊：資訊與決策科學研究所研究生蔡孟珊、張詠絮、李昀珊、優化生師比計畫研究助理馬西迪，指導教授：鄒慶士",
               style={
                   'marginTop' : "10px",
                   'textAlign' : "center",
                   })
        )
    
@callback(Output('tabs-job-type', 'children'),
          Input('lang_jobtype_checklist', 'value'))

def change_tab(select):
    if select == "English":
        return dcc.Tab(label='Graduated for 1 year', value='1年'),dcc.Tab(label='Graduated for 3 year', value='3年')
    else:
        return dcc.Tab(label='畢業滿1年', value='1年'),dcc.Tab(label='畢業滿3年', value='3年')
    
@callback(
    Output('job-types', 'options'),
    Input('lang_jobtype_checklist', 'value')
)

def set_lang(select):
    if not select:
        return no_update
    else:
        return [{'label': i, 'value': i} for i in all_option[select]]

# Define the callback function to update the content based on the value of the tabs
@callback(
    Output('tabs-content-job-type', 'children'),
    [Input('lang_jobtype_checklist','value'),
     Input('tabs-job-type', 'value'),
     Input('job-types', 'value')]
)
def update_content(select, selected_tab, selected_job_types):
    if select == "English":

        df = pd.read_parquet('./datas/gradjobtype_en.parquet')
        # Filter out data for selected years
        filtered_data = df[df['畢業滿_年'] == int(selected_tab[0])]

        # Remove data for which the Job Occupation Type field is unselected
        filtered_data = filtered_data[filtered_data['Job Occupation Types'].isin(selected_job_types)]

        # Grouping and counting by type of work occupation
        grouped_data = filtered_data.groupby(['Job Occupation Types']).size().reset_index(name='Number of people')

        # Drawing of horizontal stripes
        fig = px.bar(grouped_data, x='Number of people', y='Job Occupation Types', orientation='h',   
                    labels={'Number of people': 'Number of people', 'Job Occupation Types': 'Job Occupation Types'})
    
    else:
        df = pd.read_parquet('./datas/gradjobtype.parquet')
        # Filter out data for selected years
        filtered_data = df[df['畢業滿_年'] == int(selected_tab[0])]

        # Remove data for which the Job Occupation Type field is unselected
        filtered_data = filtered_data[filtered_data['工作職業類型'].isin(selected_job_types)]

        # Grouping and counting by type of work occupation
        grouped_data = filtered_data.groupby(['工作職業類型']).size().reset_index(name='人數')

        # Drawing of horizontal stripes
        fig = px.bar(grouped_data, x='人數', y='工作職業類型', orientation='h',   
                    labels={'人數': '人數', '工作職業類型': '工作職業類型'})
    
    return dcc.Graph(figure=fig)


