import dash
import dash_bootstrap_components as dbc
from dash import callback, dcc, html, Input, Output

dash.register_page(__name__, path='/',
                   external_stylesheets=[dbc.themes.BOOTSTRAP],
                   meta_tags=[{'name': 'viewport',
                        'content': 'width=device-width, initial-scale=1.0, maximum-scale=1.2, minimum-scale=0.5,'}]
                   )

lang = ["中文", 'English']


layout = html.Div([
    html.Div([
        dbc.Row([dbc.Col(dcc.RadioItems(id='tab_lang_checklist', 
                            options=lang,
                            value="中文",
                            labelStyle={"margin":"0.2rem"},
                            inline=True,
                            ),
                         )], align="end"),
                
        
                dbc.Tabs(id="tabs",
                children=[
                    dbc.Tab(label="學生", tab_id="stdent"), 
                    dbc.Tab(label="學校事務", tab_id="schafr") 
                ],
                active_tab="stdent",
                ),
                
                html.Div(id='tab-Out', 
                         ),
            ]),
])
########################TAB LABEL########################################
@callback(Output('tabs', 'children'),
          Input('tab_lang_checklist', 'value')
          )

def change_tab(select):
    if select == "English":
        return dbc.Tab(label="Student", tab_id="stdent"),dbc.Tab(label="School Affair", tab_id="schafr") 
    else:
        return dbc.Tab(label="學生", tab_id="stdent"),dbc.Tab(label="學校事務", tab_id="schafr") 

########################TAB CONTAINERS########################################
@callback(Output('tab-Out','children'),
         Input('tabs','active_tab'),
         Input('tab_lang_checklist', 'value')
         )

##############################################################################
def render_content(tab, select):
    
    font = "32px"
    def lang_translate(id_triger):
        container = []
        if id_triger == "English":
            container = [ "Analysis of Enrollment Pipeline Numbers", "Male-Female Ratio", "Number of People in Each Department",
                         "Number of Graduates by Department","Graduates' Job Types", "Number of Graduates Working in Various Counties and Cities after Graduation",
                         "Number and Registration Rate of New Students Enrolled in Each Department for Each Academic Year",
                         "Total Student Internship Hours","Sister Schools","Student-Teacher Ratio","Library Resources",
                         "Number of Full-time and Part-time Teachers","Number of Students with Tuition and Fee Exemptions",
                         "Association of Suspension with Departments", "Association of Dropout with Departments",
                         "Number of Suspensions and Dropouts in Admission Pathways",
                         "Comparison Chart of Main Reasons for Suspension and Dropout in the Past Five Years",
                         "Number of Suspensions and Dropouts from Top Ten Source Schools",
                         "Comparison Chart of Total Suspensions and Dropouts by Department for Each Year","Graph"]
            return container
        else:
            container = ["學年各系所學生人數", "男女生人數比較雷達圖","各系所的實習總時數","各系所畢業人數",
                          "入學管道人數分析", "畢業生工作類型", "畢業後在各縣市工作的畢業生人數",
                        "各學年度各系新生註冊人數與註冊率","姊妹校","師生比","圖書館資源","專兼任教師人數","學生學雜費減免人數","休學與學系之關聯","退學與學系之關聯","入學管道的休退學人數",
                         "近五年主要休退學原因比較圖","生源學校前十名休退學生人數","每年度各系所休退學總人數比較圖",
                         "圖表"]
            return container
    
    translate = lang_translate(select)
    
    
    if tab == 'stdent':
        return html.Div([
            ################################ ROW 1
            dbc.Row(
            [
                ############## 1 學年各系所學生人數
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[0],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/student/stddistbyyear", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 2 男女生人數比較雷達圖
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[1],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/student/stdngenderratio", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 3 各系所的實習總時數
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[2],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/student/stdintern", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 4 各系所畢業人數分布
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[3],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/student/numgradbydepinst", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
            ],
            # align="start",
            className="g-0",
            style={'marginLeft':"10px"},
        ),
            ################################ ROW 2
            dbc.Row(
            [
                ############## 5 入學管道、性別與學院之間的桑基圖
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[4],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/student/entrypathgender", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 6 各學院畢業就業類型
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[5],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/student/gradjobtype", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 7 畢業後在各縣市工作的畢業生人數
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[6],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/student/gradworkarea", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 8 各學年度各系新生註冊人數與註冊率
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[7],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/student/regratenewenroll", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
            ],
            className="g-0",
            style={'marginLeft':"10px"},
            # align="start",
        ),
            ####################################
            
        ])
        ###############################SCHOOL AFFAIR#########################################
    elif tab == 'schafr':
        return html.Div([
            ################################ ROW 1
            dbc.Row(
            [
                ############## 9  大學國際姊妹校分布圖
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[8],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/schoolafair/brosischool", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 10 各學年度日間學制師生比與師生人數
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[9],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/schoolafair/stdtchrratio", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 11 學年度圖書館館藏分類
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[10],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/schoolafair/libraryresources", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 12 各學年度日間學制專/兼任教師人數
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[11],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/schoolafair/numfulltimeparttim", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
            ],
            # align="start",
            className="g-0",
            style={'marginLeft':"10px"},
        ),
            ################################ ROW 2
            dbc.Row(
            [
                ############## 13  學雜費減免人數
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[12],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/schoolafair/numstdfrtuition", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 14  大學休學原因與學系之間的熱圖及分佈情況
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[13],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/schoolafair/assosusdept", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 15  大學休學原因與學系之間的熱圖及分佈情況
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[14],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/schoolafair/assouttdept", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),  
                ############## 16  系所的入學管道修休退學人數 (學年度 108-112)
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[15],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/schoolafair/dropoutstdnsix", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 }
                    )),                                       
            ],
            # align="start",
            className="g-0",
            style={'marginLeft':"10px"},
            ),
            ################################ ROW 3
            dbc.Row(
            [
                ############## 17  近五年主要休退學原因比較圖
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[16],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/schoolafair/mainfiveoutrest", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 18  前十名生源學校的退學人數 (學年度 108-112)
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[17],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/schoolafair/dropoutstdn", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
                ############## 19  每年度各系所休退學總人數比較圖
                dbc.Col(html.Div([
                    dbc.Row([dbc.Col(html.Div([
                        html.P(translate[18],
                                style={
                                    'height':"80px",
                                    'marginTop':"10px",
                                    'marginLeft':"10px",
                                    'fontSize': "28px"
                                    }),
                                ])),
                             ]),
                    dbc.Row([dbc.Col(html.Div([
                        dcc.Link(html.Button(translate[19], 
                                            style={
                                                'marginTop':"30px",
                                                'backgroundColor':"#800080",
                                                'color':"white",
                                                'marginLeft':"78%",
                                                'borderRadius':"8px",
                                                'borderWidth': "thin",
                                                'borderStyle':"solid",
                                                'borderColor':"#C6C4C4",
                                    }), href="/schoolafair/yearoutrestnum", refresh=True,)
                                ])),
                             ]),
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'marginLeft':"10px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),                                    
                ############## 
                dbc.Col(html.Div([
                    ########
                    ],
                                 style={
                                 'marginTop':"20px",
                                 'height':"180px",
                                 'width':"350px",
                                 'borderRadius':"8px",
                                 'borderWidth': "thin",
                                 'borderStyle':"solid",
                                 'borderColor':"white",#"#C6C4C4",
                                 'backgroundColor':"white"
                                 })),
            ],
            # align="start",
            className="g-0",
            style={'marginLeft':"10px"},
        ),
            #########################################################
        ])

